export default {
  colors: {
    backgroundColor: "#3646AA",
    primary: "#5CD4A0",
    secondary: "#F2F2F2",
    danger: "#9B291F",
    purple: "#8e44ad",
    textNormal: "#3C4659",
    textLight: "#ADADC4",
    red: "#8F0000",
    green: "#3FA69A"
  }
};
