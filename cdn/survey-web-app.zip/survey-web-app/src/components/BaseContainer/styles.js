import styled from "styled-components";

export const Container = styled.div`
  max-width: 1200px;
  align-self: center;
  justify-self: center;
  flex: 1;
`;
