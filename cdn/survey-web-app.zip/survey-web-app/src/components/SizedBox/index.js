import React from "react";

import { Container } from "./styles";

export default function SizedBox({ ...props }) {
  return <Container {...props} />;
}
