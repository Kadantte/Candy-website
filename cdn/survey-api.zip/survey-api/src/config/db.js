const mongoose = require('mongoose')

const MONGOURI = process.env.MONGODB_URI || "mongodb+srv://kada:Kada93@cluster0.l1acq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

const InitiateMongoServer = () => {
	mongoose.connect(MONGOURI, {
		useNewUrlParser: true,
		useUnifiedTopology: true
	}).then(() => {
		console.log('connected to mongodb!')
	}).catch(() => {
		console.log('error connecting to db')
	})
}

module.exports = InitiateMongoServer
